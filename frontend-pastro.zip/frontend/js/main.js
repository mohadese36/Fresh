
// main.js
console.log("✅ main.js loaded");

// همه jsها رو یکجا import کن
 import("./menu.js");
 import("./index.js");
 import("./search.js");
 import("./login-form.js");
 import("./user-header.js");
 import("./featured-products-page.js");
 import("./categori.js");
 import("./ourMenu.js");
 import("./basket-box.js");
 import("./article.js");
 import("./breadcrumb.js");
 import("./related-products.js");
 import("./cart.js");
 import("./checkout.js");
 import("./productDetails.js");
 import("./user-auth.js");
 import("./user.js");
